﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyXamarinApp.Core.ViewModels.Main
{
    public class MainContainerViewModel : BaseViewModel
    {
    }
}
